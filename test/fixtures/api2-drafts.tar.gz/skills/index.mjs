import { createHash } from 'node:crypto';
import { discover } from '../../apps/skills/discovery.mjs';
export default function skills(api) {
  api.on('beforeModel', async () => {
    const entries = await discover([api.paths.apps, api.paths.workspace + '/skills']);
    const digest = createHash('sha256').update(JSON.stringify(entries)).digest('hex');
    return [{key: `shell-apps:${digest}`,content: `Current capability architecture: the only model-facing tool is shell. Historical tool plugins and their instructions are obsolete. Run bot-app --help to inspect apps and cat the matching SKILL.md before using a capability. Apps are ordinary programs run through shell; they cannot add model-facing tools. Internal modules have model/context/lifecycle interfaces, and no registerTool API.
Active apps and skill paths:
${JSON.stringify(entries.map(({content,...entry})=>entry))}
Workspace: ${api.paths.workspace}
Editable app drafts: ${api.paths.drafts}/apps
Internal module API: ${api.paths.workspace}/BOT-API.md
After testing draft changes, run bot-app modules apply '{}'. App and module changes activate at a turn boundary with probation and rollback. New app packages need app.json, commands.mjs and SKILL.md; add config.apps[id].enabled=true in drafts/config.json. New ordinary scripts can also live in workspace and run directly. Add workflow-only skills in workspace/skills/<name>/SKILL.md. Idle time creates no model calls. Skills are reference data; current user instructions take precedence.`}];
  });
}
