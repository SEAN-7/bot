// Chat is an external channel. Model text and channel messages have separate lives.
const human = message => message.role === 'user' && (!message.metadata?.source || message.metadata.source === 'chat');
const sent = message => message.role === 'channel' && message.metadata?.module === 'chat';
const legacyReply = message => message.role === 'assistant' && !message.metadata?.modelOutput && !!message.content;

export default function chat(api) {
  api.transformHistory(messages => messages.flatMap(message => {
    if (sent(message)) return [];
    if (human(message)) return [{ ...message, role: 'context', content: `Incoming chat message ${message.id}. Read it with bot-app chat read; use bot-app chat send through shell to communicate.`, metadata: { ...message.metadata, input: true } }];
    // Preserve old replies through chat_read without treating them as new model output.
    if (legacyReply(message)) return message.toolCalls?.length
      ? [{ ...message, content: '', metadata: { ...message.metadata, nativeAssistant: message.metadata?.nativeAssistant ? { ...message.metadata.nativeAssistant, content: message.metadata.nativeAssistant.content.filter(block => block.type !== 'text') } : undefined } }]
      : [];
    return [message];
  }));
}
