export function commands(api) {
  return { apply: {
    description: 'Validate and stage all app and internal module drafts. Switch at a turn boundary, with probation and rollback. Core remains operator-owned.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    execute: () => api.proposeUpdate(),
  } };
}
