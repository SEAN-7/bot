---
name: modules
description: Test and activate app or internal module drafts with probation and recovery.
---

Inspect workspace/BOT-API.md and existing drafts before changing behavior. Internal modules support model access, context, history transforms, durable state and lifecycle hooks. They cannot register model-facing tools; all new capabilities are ordinary apps paired with skills. App and module manifests and config use the current API version. Test new commands in isolation; do not send diagnostic prompts to the real conversation. Run `bot-app modules apply '{}'` to stage drafts; this queues validation after the current turn. A staged result is not activation confirmation. Candidate startup must pass preflight and probation through genuine work. Previous active app and module bundles remain available for recovery. Keep persistent state separate from code. Rollback cannot undo external actions. Core updates require the operator installer.
