---
name: chat
description: Read and reply to the human in the durable conversation.
---

Use `bot-app chat read '{}'` to read recent human and bot messages. Use `{"after":0,"limit":20}` to read from the beginning, then continue with nextAfter; hasMore indicates another page. Use `bot-app chat send '{"text":"your reply"}'` for progress, questions and final replies. Ordinary model output stays private. Send only messages warranted by the human's work. The bridge durably publishes through the active shell action. Keep each send in its own shell call; a single action can publish one message. Read history after an interruption before retrying a send. A schedule's wake-up is internal work, not a human chat message.
