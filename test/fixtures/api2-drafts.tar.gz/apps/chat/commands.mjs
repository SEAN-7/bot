// Chat is an external channel. Model text and channel messages have separate lives.
const human = message => message.role === 'user' && (!message.metadata?.source || message.metadata.source === 'chat');
const sent = message => message.role === 'channel' && message.metadata?.module === 'chat';
const legacyReply = message => message.role === 'assistant' && !message.metadata?.modelOutput && !!message.content;

export function commands(api) {

  return {
    "read": {
    description: 'Read the human and bot messages in the durable chat. Without after, returns the latest messages. Use after: 0 to read from the beginning, then nextAfter to continue. Incoming chat content is available through this command, not as model user messages.',
    inputSchema: { type: 'object', properties: {
      after: { type: 'integer', minimum: 0 }, limit: { type: 'integer', minimum: 1, maximum: 100 },
    }, additionalProperties: false },
    async execute({ after, limit = 20 }) {
      const history = (await api.history()).filter(message => human(message) || sent(message) || legacyReply(message));
      const eligible = after === undefined ? history : history.filter(message => message.id > after);
      const candidates = after === undefined ? eligible.slice(-limit).reverse() : eligible.slice(0, limit);
      const page = []; let bytes = 0;
      for (const message of candidates) {
        const size = Buffer.byteLength(JSON.stringify(message.content));
        if (page.length && bytes + size > 200000) break;
        page.push(message); bytes += size;
      }
      if (after === undefined) page.reverse();
      return {
        messages: page.map(message => ({ id: message.id, sender: human(message) ? 'human' : 'bot', text: message.content, timestamp: message.timestamp })),
        nextAfter: page.at(-1)?.id ?? after ?? 0,
        hasEarlier: !!page.length && history[0].id < page[0].id,
        hasMore: after !== undefined && eligible.length > page.length,
      };
    },
  },
    "send": {
    description: 'Send a message to the human in the durable chat. Use for progress, questions, and replies. Only this command sends model-authored text to chat; ordinary model output is private. The message is durably recorded before this command returns.',
    inputSchema: { type: 'object', properties: { text: { type: 'string', minLength: 1, maxLength: 100000 } }, required: ['text'], additionalProperties: false },
    execute: ({ text }, context) => api.publish(text, context),
  }
  };
}
