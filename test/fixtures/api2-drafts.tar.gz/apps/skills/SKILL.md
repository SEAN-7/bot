---
name: skills
description: Discover apps and workflow skills, inspect capabilities and author new app packages.
---

Run `bot-app skills list '{}'` for skill names, descriptions and paths. Read a guide with `cat /absolute/path/SKILL.md` or `bot-app skills read '{"name":"chat"}'`. Run `bot-app APP --help` for arguments. Programs return JSON on stdout and failures on stderr with nonzero exit codes. Add ordinary programs in workspace, and pair them with workspace/skills/<name>/SKILL.md using single-line name and description frontmatter. For a recoverable app package, put app.json (id, version, entry: commands.mjs, description), commands.mjs and SKILL.md under drafts/apps/<id>; enable config.apps[id] and activate with bot-app modules apply after testing. See BOT-API.md for the app CLI contract. No module can register tools. Shell uses command OR sessionId: poll, send chars, endInput, or terminate through the same shell tool. Commands are supervised and stop on cancellation/restart. Inspect uncertain side effects before replay. Do not detach background services.

Use `bot-app skills usage '{}'` to inspect recorded token usage and estimated costs without direct journal access. Context-summary model calls are not included. Missing metrics mean unavailable.
